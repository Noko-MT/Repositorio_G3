package com.Seguridad.Registraduria_Seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistraduriaSeguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
