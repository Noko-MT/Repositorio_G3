package com.Seguridad.Registraduria_Seguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistraduriaSeguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistraduriaSeguridadApplication.class, args);
	}

}
